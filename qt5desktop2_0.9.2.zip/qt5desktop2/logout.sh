#!/bin/bash

kill `pgrep -f openbox`
