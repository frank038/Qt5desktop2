#!/bin/bash

# echo "1label1"
echo `date +%H:%M:%S`
