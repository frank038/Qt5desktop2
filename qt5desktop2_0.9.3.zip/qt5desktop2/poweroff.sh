#!/bin/bash
/usr/bin/systemctl poweroff
