#!/bin/bash

# echo "2label2"
echo `date +%H:%M:%S`
