#!/bin/bash
/usr/bin/systemctl reboot
